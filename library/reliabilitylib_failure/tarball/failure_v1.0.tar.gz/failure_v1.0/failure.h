#ifndef __FAILURE_MODEL_H__
#define __FAILURE_MODEL_H__

enum FAILURE_MODEL_TYPE {
    FAILURE_MODEL_NONE = 0,
    FAILURE_MODEL_HCI, // HOT_CARRIER_INJECTION
    FAILURE_MODEL_EM, // ELECTROMIGRATION
    FAILURE_MODEL_NBTI, // NEGATIVE_BIAS_TEMPERATURE_INSTABILITY
    FAILURE_MODEL_PBTI, // POSITIVE_BIAS_TEMPERATURE_INSTABILITY
    FAILURE_MODEL_SM, // STRESS_MIGRATION
    FAILURE_MODEL_TC, // THERMAL_CYCLING
    FAILURE_MODEL_TDDB, // TIME_DEPENDENT_DIELECTRIC_BREAKDOWN
    NUM_FAILURE_MODEL_TYPES
};

class failure_model_config_t
{
public:
    failure_model_config_t();
    ~failure_model_config_t();
    
    // lambda_HCI = coeff * (I_sub)^n * exp(-Ea/{kT}), and I_sub ~ Vdd
    struct {
        double coeff;
        double n;
        double Ea;
        bool used;
    }HCI;
    
    // lambda_EM = coeff * J^n * exp(-Ea/{kT})
    // J = Vdd * C/{WH}, where C/{WH} is programmed in the code.
    struct {
        double coeff;
        double J;
        double n;
        double Ea;
        bool used;
    }EM;
    
    // lambda_NBTI = coeff * Eox^n * exp(-Ea/{kT}), and Eox ~ Vdd
    struct {
        double coeff;
        double n;
        double Ea;
        bool used;
    }NBTI;
    
    // lambda_PBTI = TODO
    struct {
        double coeff;
        bool used;
    }PBTI;
    
    // lambda_SM = coeff * (T0-T)^n * exp(-Ea/{kT})
    struct {
        double coeff;
        double T0;
        double n;
        double Ea;
        bool used;
    }SM;
    
    // lambda_TC = coeff * (T-T_amb)^n
    struct {
        double coeff;
        double n;
        bool used;
    }TC;
    
    // lambda_TDDB = coeff * V^(c*{a+bT}) * exp({x + y/T + zT}/{kT})
    struct {
        double coeff;
        double a;
        double b;
        double c;
        double x;
        double y;
        double z;
        bool used;
    }TDDB;
    
    struct {
        double Temp; // Target temperature that meets the MTTF
        double Vdd; // Target voltage that meets the MTTF
        double Freq; // Target frequency that meets the MTTF
        double MTTF; // Target MTTF
    }baseline;
    
    // Default/common parameters
    double k; // Boltzmann constant
    double Temp; // Operating temperature;
    double Temp_ambient; // Ambient temperature
    double Vdd; // Operating voltage;
    double Freq; // Operating frequency;
};

class failure_model_t
{
public:
    failure_model_t();
    ~failure_model_t();
    
    void initialize(failure_model_config_t *ModelConfig);
    double get_failure_rate(int Type);
    
private:
    failure_model_config_t *model_config;
    int num_models;
};

#endif
