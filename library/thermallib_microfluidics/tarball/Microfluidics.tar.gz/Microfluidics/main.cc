#include <iostream>
#include "microfluidics.h"

using namespace std;

int main(void)
{
    // Create microfluidics model and initialize the config parameters to default.
    microfluidics_t *microfluidics = new microfluidics_t();
    
    /**********************************************************
     If necessary, customize the config parameters here.
     **********************************************************/
    // Pin Fin dimension
    microfluidics->config->HC = 200e-6;
    microfluidics->config->Dp = 100e-6;
    microfluidics->config->NW = 34;
    microfluidics->config->NH = 34;
    
    // Chip dimension
    // Note: W and H will be automatically found by checking floorplan dimension
    microfluidics->config->ThSi = 100e-6;
    microfluidics->config->ThO = 10e-6;
    microfluidics->config->ThB = 10e-6;
    
    // Pumping power
    microfluidics->config->PPower = 0.03;
    
    // Initial thermal conditions
    microfluidics->config->heff = 562.28;
    microfluidics->config->hamb = 10.0;
    microfluidics->config->Tfin = 273.15+20.0;
    microfluidics->config->Twini = 273.15+20.0;
    microfluidics->config->Tamb = 273.15+20.0;
    
    // Material properties
    microfluidics->config->rho_Si = 2330.0;
    microfluidics->config->cp_Si = 707.0;
    microfluidics->config->k_Si = 149.0;
    microfluidics->config->rho_O = 220.0;
    microfluidics->config->k_O = 1.4;
    microfluidics->config->cp_B = 1000.0;
    microfluidics->config->k_B = 1.4;
    microfluidics->config->rho_f = 997.0;
    microfluidics->config->cp_f = 4183.0;
    microfluidics->config->k_f = 0.5945;
    microfluidics->config->mu_f = 0.0008936;
    
    microfluidics->config->thermal_mapping_type = MICROFLUIDICS_THERMAL_MAPPING_AVERAGE;
    
    // Create and add floorplans (Name, XLeft, YBottom, Width (X-Dim), Height (Y-Dim), Layer)
    // Note: Use of Width and Length can cause confusion because some people perceive
    // Width as Y-Dim and Length as X-Dim metrics, or vice versa.
    // Using Width and Height is to denote X-Dim and Y-Dim, respectively, is less likely
    // to be misunderstood.
    microfluidics->add_floorplan("proc_left_bottom",0.0e-3,0.0e-3,4.2e-3,4.2e-3,0);
    microfluidics->add_floorplan("proc_right_bottom",4.2e-3,0.0e-3,4.2e-3,4.2e-3,0);
    microfluidics->add_floorplan("proc_left_top",0.0e-3,4.2e-3,4.2e-3,4.2e-3,0);
    microfluidics->add_floorplan("proc_right_top",4.2e-3,4.2e-3,4.2e-3,4.2e-3,0);
    
    microfluidics->add_floorplan("mem_left_bottom",0.0e-3,0.0e-3,4.2e-3,4.2e-3,1);
    microfluidics->add_floorplan("mem_right_bottom",4.2e-3,0.0e-3,4.2e-3,4.2e-3,1);
    microfluidics->add_floorplan("mem_left_top",0.0e-3,4.2e-3,4.2e-3,4.2e-3,1);
    microfluidics->add_floorplan("mem_right_top",4.2e-3,4.2e-3,4.2e-3,4.2e-3,1);
    
    // Check floorplans and create power grid.
    microfluidics->initialize();
    
    // Set floorplan power.
    microfluidics->set_floorplan_power("proc_left_bottom",10.0);
    microfluidics->set_floorplan_power("proc_right_bottom",20.0);
    microfluidics->set_floorplan_power("proc_left_top",30.0);
    microfluidics->set_floorplan_power("proc_right_top",40.0);
    
    microfluidics->set_floorplan_power("mem_left_bottom",6.75);
    microfluidics->set_floorplan_power("mem_right_bottom",6.75);
    microfluidics->set_floorplan_power("mem_left_top",6.75);
    microfluidics->set_floorplan_power("mem_right_top",6.75);
    
    // Convert floorplan power to grid.
    microfluidics->convert_floorplan_to_grid_power();
    
    // Calculate steady-state temperature
    microfluidics->calculate_steady_state_temperature();
    
    // Calculate transient temperature
    //microfluidics->calculate_transient_temperature(1.0);
    
    microfluidics->convert_grid_to_floorplan_temperature();
    
    cout << "proc_left_bottom.temperature=" << microfluidics->get_floorplan("proc_left_bottom")->get_temperature() << endl;
    cout << "proc_right_bottom.temperature=" << microfluidics->get_floorplan("proc_right_bottom")->get_temperature() << endl;
    cout << "proc_left_top.temperature=" << microfluidics->get_floorplan("proc_left_top")->get_temperature() << endl;
    cout << "proc_right_top.temperature=" << microfluidics->get_floorplan("proc_right_top")->get_temperature() << endl;
    cout << endl;
    cout << "mem_left_bottom.temperature=" << microfluidics->get_floorplan("mem_left_bottom")->get_temperature() << endl;
    cout << "mem_right_bottom.temperature=" << microfluidics->get_floorplan("mem_right_bottom")->get_temperature() << endl;
    cout << "mem_left_top.temperature=" << microfluidics->get_floorplan("mem_left_top")->get_temperature() << endl;
    cout << "mem_right_top.temperature=" << microfluidics->get_floorplan("mem_right_top")->get_temperature() << endl;

    delete microfluidics;
    
    return 0;
}
