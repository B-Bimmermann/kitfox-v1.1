#ifndef __COMPACT_MICROFLUIDICS_H__
#define __COMPACT_MICROFLUIDICS_H__

#include <map>
#include <vector>

enum MICROFLUIDICS_PACKAGE_LAYER_MODELS {
    MICROFLUIDICS_PACKAGE_LAYER_UNKNOWN = 0,
    MICROFLUIDICS_PACKAGE_PROCESSOR_LAYER,
    MICROFLUIDICS_PACKAGE_MEMORY_LAYER,
    NUM_MICROFLUIDICS_PACKAGE_LAYER_MODELS
};

enum MICROFLUIDICS_THERMAL_MAPPING_TYPES {
    MICROFLUIDICS_THERMAL_MAPPING_UNKNOWN = 0,
    MICROFLUIDICS_THERMAL_MAPPING_CENTER,
    MICROFLUIDICS_THERMAL_MAPPING_AVERAGE,
    MICROFLUIDICS_THERMAL_MAPPING_MAX,
    MICROFLUIDICS_THERMAL_MAPPING_MIN,
    NUM_MICROFLUIDICS_THERMAL_MAPPING_TYPES
};

// Configuration
class microfluidics_config_t
{
public:
    microfluidics_config_t();
    ~microfluidics_config_t();
    
    // Set default values
    void init_default();
    
    // Pin Fin dimensions
    double HC, Dp, ST, SL;
    
    // Chip dimension
    double W, H, ThSi, ThO, ThB;
    
    // Pumping power
    double PPower;
    
    // Initial thermal conditions
    double heff, hamb, Tfin, Twini, Tamb;
    
    // Material properties
    double rho_Si, cp_Si, k_Si, rho_O, k_O, cp_B, k_B;
    double rho_f, cp_f, k_f, mu_f;

    // Number of Pin Fins at each dimension
    unsigned NW, NH; // X-Dim, Y-Dim
    // Matrix size
    unsigned Nx, Ny, Nz; // columns, rows, layers
        
    // Error tolerance when checking the floorplan dimension
    double floorplan_precision;
    
    // Grid to floorplan thermal mapping type
    int thermal_mapping_type;
};





// Floorplan
class microfluidics_floorplan_t
{
public:
    microfluidics_floorplan_t(std::string Name, double XLeft, double YBottom, double Width, double Height, unsigned Layer);
    ~microfluidics_floorplan_t();
    
    std::string get_name() const;
    
    const double get_x_left() const;
    const double get_x_right() const;
    const double get_x_center() const;
    const double get_y_bottom() const;
    const double get_y_top() const;
    const double get_y_center() const;
    const unsigned get_layer() const;
    const double get_area() const;
    void set_x_shift(double XShift);
    void set_y_shift(double YShift);
    void set_grid_index(double CellWidth, double CellHeight);
    
    void set_power(double Power);
    const double get_power() const;
    
    void set_temperature(double Temperature);
    const double get_temperature() const;
    
    // Grid cell indices
    struct {
        unsigned left_index, right_index;
        unsigned bottom_index, top_index;
        double cell_width, cell_height;
        double boundary_proportion[4];
    }grid;
    
private:
    // Floorplan name
    std::string name;

    // Floorplan dimension    
    double x_left, y_bottom;
    double width, height;
    unsigned layer;
    
    // Floorplan power
    double power;
    
    // Floorplan temperature
    double temperature;
};





// Microfluidics model
class microfluidics_t
{
public:
    microfluidics_t();
    ~microfluidics_t();

    // Create and add floorplans.
    void add_floorplan(std::string Name, double XLeft, double YBottom, double Width, double Height, unsigned Layer);    
    // Get floorplan index in the vector. The index is used like floorplan's ID.
    const unsigned get_floorplan_index(std::string Name);
    microfluidics_floorplan_t* get_floorplan(std::string Name);
    microfluidics_floorplan_t* get_floorplan(unsigned Index);
    // Check floorplans and create power grid.
    void initialize();
    // Set floorplan power, identified by string name or index ID.
    void set_floorplan_power(std::string Name, double Power);
    void set_floorplan_power(unsigned Index, double Power);
    // Convert floorplan to grid power.
    void convert_floorplan_to_grid_power();
    // Convert grid to floorplan temperature.
    void convert_grid_to_floorplan_temperature(int MappingType = MICROFLUIDICS_THERMAL_MAPPING_UNKNOWN);
    // Steady-state temperature calculator
    void calculate_steady_state_temperature();
    // Transient temperature calculator
    void calculate_transient_temperature(double Period);
    
    microfluidics_config_t *config;
    double *power_grid;
    double *Tw_grid;
    double *Tf_grid;
            
private:
    void check_floorplan(microfluidics_floorplan_t *Floorplan);
    
    std::vector<microfluidics_floorplan_t*> floorplans;
    std::map<std::string,unsigned> floorplans_index;
};

#endif
