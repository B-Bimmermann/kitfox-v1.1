#include <iostream>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <assert.h>
#include "microfluidics.h"

using namespace std;

// Configuration
microfluidics_config_t::microfluidics_config_t() :
    W(0.0), H(0.0),
    NW(0), NH(0),
    Nx(0), Ny(0), Nz(0),
    floorplan_precision(1e-12),
    thermal_mapping_type(MICROFLUIDICS_THERMAL_MAPPING_AVERAGE)
{
}

microfluidics_config_t::~microfluidics_config_t()
{
}

void microfluidics_config_t::init_default()
{
    // Pin Fin dimension
    HC = 200e-6; Dp = 100e-6; 
    // Note: ST and SL are determined by user-given NW and NH.
    //ST = 250e-6; SL = 250e-6;
    
    // Chip dimension
    //W = 8400e-6; H = 8400e-6; 
    ThSi = 100e-6; ThO = 10e-6; ThB = 10e-6;
    
    // Pumping power
    PPower = 0.03;
    
    // Initial thermal conditions
    heff = 562.28; hamb = 10.0; Tfin = 273.15+20.0; Twini = 273.15+20.0; Tamb = 273.15+20.0;
    
    // Material properties
    rho_Si = 2330.0; cp_Si = 707.0; k_Si = 149.0; rho_O = 220.0; k_O = 1.4; cp_B = 1000.0; k_B = 1.4;
    rho_f = 997.0; cp_f = 4183.0; k_f = 0.5945; mu_f = 0.0008936; 
}





// Floorplan
microfluidics_floorplan_t::microfluidics_floorplan_t(string Name, double XLeft, double YBottom, 
                                                     double Width, double Height, unsigned Layer) :
    name(Name),
    x_left(XLeft),
    y_bottom(YBottom),
    width(Width),
    height(Height),
    layer(Layer)
{
}

microfluidics_floorplan_t::~microfluidics_floorplan_t()
{
}

string microfluidics_floorplan_t::get_name() const { return name; }
const double microfluidics_floorplan_t::get_x_left() const { return x_left; }
const double microfluidics_floorplan_t::get_x_right() const { return (x_left+width); }
const double microfluidics_floorplan_t::get_x_center() const { return (x_left+width/2.0); }
const double microfluidics_floorplan_t::get_y_bottom() const { return y_bottom; }
const double microfluidics_floorplan_t::get_y_top() const { return (y_bottom+height); }
const double microfluidics_floorplan_t::get_y_center() const { return (y_bottom+height/2.0); }
const unsigned microfluidics_floorplan_t::get_layer() const { return layer; }
const double microfluidics_floorplan_t::get_area() const { return (width*height); }
void microfluidics_floorplan_t::set_x_shift(double XShift) { x_left += XShift; }
void microfluidics_floorplan_t::set_y_shift(double YShift) { y_bottom += YShift; }
void microfluidics_floorplan_t::set_power(double Power) { power = Power; }
const double microfluidics_floorplan_t::get_power() const { return power; }
void microfluidics_floorplan_t::set_temperature(double Temperature) { temperature = Temperature; }
const double microfluidics_floorplan_t::get_temperature() const { return temperature; }

void microfluidics_floorplan_t::set_grid_index(double CellWidth, double CellHeight)
{
    // Grid cell information
    grid.cell_width = CellWidth;
    grid.cell_height = CellHeight;
    
    // Boundary indices
    grid.left_index = (unsigned)(get_x_left()/grid.cell_width)+1;
    grid.right_index = (unsigned)(get_x_right()/grid.cell_width)+1;
    grid.bottom_index = (unsigned)(get_y_bottom()/grid.cell_height)+1;
    grid.top_index = (unsigned)(get_y_top()/grid.cell_height)+1;
    
#ifdef MICROFLUIDICS_DEBUG
    cout << "Grid cell = (" << grid.cell_width*1e3 << "mm*" << grid.cell_height*1e3 << "mm)" << endl;
    cout << "Floorplan " << get_name() << ": " << endl;
    cout << "\tleft = " << get_x_left()*1e3 << "mm (" << grid.left_index << ")" << endl;
    cout << "\tright = " << get_x_right()*1e3 << "mm (" << grid.right_index << ")" << endl;
    cout << "\tbottom = " << get_y_bottom()*1e3 << "mm (" << grid.bottom_index << ")" << endl;
    cout << "\ttop = " << get_y_top()*1e3 << "mm (" << grid.top_index << ")" << endl;
#endif
    
    // Determine the proportion of boundary cells, assuming floorplans do not perfectly align
    // with grid cell boundaries.
    grid.boundary_proportion[0] = ((double)grid.left_index*grid.cell_width - get_x_left())/grid.cell_width;
    grid.boundary_proportion[1] = (get_x_right() - (double)(grid.right_index-1)*grid.cell_width)/grid.cell_width;
    grid.boundary_proportion[2] = ((double)grid.bottom_index*grid.cell_height - get_y_bottom())/grid.cell_height;
    grid.boundary_proportion[3] = (get_y_top() - (double)(grid.top_index-1)*grid.cell_height)/grid.cell_height;
    
#ifdef MICROFLUIDICS_DEBUG
    cout << "\tboundary_proportion[left] = " << grid.boundary_proportion[0] << endl;
    cout << "\tboundary_proportion[right] = " << grid.boundary_proportion[1] << endl;
    cout << "\tboundary_proportion[bottom] = " << grid.boundary_proportion[2] << endl;
    cout << "\tboundary_proportion[top] = " << grid.boundary_proportion[3] << endl;
#endif
}





// Microfluidics model
microfluidics_t::microfluidics_t() :
    power_grid(NULL),
    Tw_grid(NULL),
    Tf_grid(NULL)
{
    config = new microfluidics_config_t();
    config->init_default();
}

microfluidics_t::~microfluidics_t()
{
    for(unsigned i = 0; i < floorplans.size(); i++)
        delete floorplans[i];
    floorplans.clear();
    floorplans_index.clear();
    delete config;
    delete [] power_grid;
    delete [] Tw_grid;
    delete [] Tf_grid;
}

void microfluidics_t::initialize() 
{
    if(floorplans.size() == 0) {
        cout << "Error (microfluidics): there are no floorplans added" << endl;
        exit(EXIT_FAILURE);
    }

    if(config->NW == 0) {
        cout << "Error (microfluidics): Number of Pin Fins in x-dimension (NW) is not defined" << endl;
        exit(EXIT_FAILURE);
    }
    if(config->NH == 0) {
        cout << "Error (microfluidics): Number of Pin Fins in y-dimension (NH) is not defined" << endl;
        exit(EXIT_FAILURE);
    }
    if(config->Nz != 2) {
        cout << "Error (microfluidics): This version supports only two-layer package model" << endl;
        exit(EXIT_FAILURE);
    }

    // Determine Pin Fin dimensions.
    config->ST = config->W/(double)config->NW;
    config->SL = config->H/(double)config->NH;

    // +2 is to cover the boundary conditions.
    config->Nx = config->NW+2;
    config->Ny = config->NH+2;

    // Check floorplan dimensions if they are overlapping of disjoint.
    for(unsigned i = 0; i < floorplans.size(); i++) {
        check_floorplan(floorplans[i]);
    }
    
    // Determine the grid indices of floorplan boundaries.
    for(unsigned i = 0; i < floorplans.size(); i++)
        floorplans[i]->set_grid_index(config->ST,config->SL);
            
    // Create power grid
    power_grid = new double[config->Nx*config->Ny*config->Nz];
    memset(power_grid,0.0,sizeof(double)*config->Nx*config->Ny*config->Nz);
    
    // Create thermal grid
    Tw_grid = new double[config->Nx*config->Ny*config->Nz];
    memset(Tw_grid,0.0,sizeof(double)*config->Nx*config->Ny*config->Nz);
    
    Tf_grid = new double[config->Nx*config->Ny*config->Nz];
    memset(Tf_grid,0.0,sizeof(double)*config->Nx*config->Ny*config->Nz);
}

void microfluidics_t::convert_floorplan_to_grid_power()
{
    for(unsigned i = 0; i < floorplans.size(); i++) {
        microfluidics_floorplan_t *floorplan = floorplans[i];
        double x_proportion, y_proportion;
        for(unsigned y = floorplan->grid.bottom_index; y <= floorplan->grid.top_index; y++) {
            if(y == floorplan->grid.bottom_index)
                y_proportion = floorplan->grid.boundary_proportion[2];
            else if(y == floorplan->grid.top_index)
                y_proportion = floorplan->grid.boundary_proportion[3];
            else
                y_proportion = 1.0;
            
            for(unsigned x = floorplan->grid.left_index; x <= floorplan->grid.right_index; x++) {
                if(x == floorplan->grid.left_index)
                    x_proportion = floorplan->grid.boundary_proportion[0];
                else if(x == floorplan->grid.right_index)
                    x_proportion = floorplan->grid.boundary_proportion[1];
                else
                    x_proportion = 1.0;
                
                // Note: use += not = because some cells may span over multiple floorplan boundaries.
                power_grid[x+y*config->Nx+floorplan->get_layer()*config->Nx*config->Ny] +=
                floorplan->get_power()*(floorplan->grid.cell_width*floorplan->grid.cell_height)/floorplan->get_area()*x_proportion*y_proportion;
            }
        }
    }
    
#ifdef MICROFLUIDICS_DEBUG
    cout << "Power grid:" << endl;
    for(unsigned z = 0; z < config->Nz; z++) {
        for(unsigned y = 0; y < config->Ny; y++) {
            for(unsigned x = 0; x < config->Nx; x++) {
                cout << power_grid[x+y*config->Ny+z*config->Nx*config->Ny] << " ";
            }
            cout << endl;
        }
        cout << endl;
    }
#endif
}

void microfluidics_t::convert_grid_to_floorplan_temperature(int MappingType)
{
    int mapping_type = MappingType;
    if(mapping_type == MICROFLUIDICS_THERMAL_MAPPING_UNKNOWN)
        mapping_type = config->thermal_mapping_type;
        
    double temperature;
        
    for(unsigned i = 0; i < floorplans.size(); i++) {
        microfluidics_floorplan_t* floorplan = floorplans[i];
        switch(mapping_type) {
            case MICROFLUIDICS_THERMAL_MAPPING_CENTER: {
                unsigned x_center = (unsigned)(floorplan->get_x_center()/floorplan->grid.cell_width)+1;
                unsigned y_center = (unsigned)(floorplan->get_y_center()/floorplan->grid.cell_height)+1;
                temperature = Tw_grid[x_center+y_center*config->Nx+floorplan->get_layer()*config->Nx*config->Ny];
                break;
            };
            case MICROFLUIDICS_THERMAL_MAPPING_AVERAGE: {
                temperature = 0.0;
                // Note: num_grid_cells may not be integer if floorplan boundaries do not perfectly align with grid cells.
                double num_grid_cells = floorplan->get_area()/(floorplan->grid.cell_width*floorplan->grid.cell_height);
                double x_proportion, y_proportion;
                for(unsigned y = floorplan->grid.bottom_index; y <= floorplan->grid.top_index; y++) {
                    if(y == floorplan->grid.bottom_index)
                        y_proportion = floorplan->grid.boundary_proportion[2];
                    else if(y == floorplan->grid.top_index)
                        y_proportion = floorplan->grid.boundary_proportion[3];
                    else
                        y_proportion = 1.0;
                    for(unsigned x = floorplan->grid.left_index; x <= floorplan->grid.right_index; x++) {
                        if(x == floorplan->grid.left_index)
                            x_proportion = floorplan->grid.boundary_proportion[0];
                        else if(x == floorplan->grid.right_index)
                            x_proportion = floorplan->grid.boundary_proportion[1];
                        else
                            x_proportion = 1.0;
                            
                        temperature += Tw_grid[x+y*config->Nx+floorplan->get_layer()*config->Nx*config->Ny]*x_proportion*y_proportion;
                    }
                }
                temperature /= num_grid_cells;
                break;
            };
            case MICROFLUIDICS_THERMAL_MAPPING_MAX: {
                temperature = 0.0;
                for(unsigned y = floorplan->grid.bottom_index; y <= floorplan->grid.top_index; y++) {
                    for(unsigned x = floorplan->grid.left_index; x <= floorplan->grid.right_index; x++) {
                        if(temperature < Tw_grid[x+y*config->Nx+floorplan->get_layer()*config->Nx*config->Ny])
                            temperature = Tw_grid[x+y*config->Nx+floorplan->get_layer()*config->Nx*config->Ny];
                    }
                }
                break;
            };
            case MICROFLUIDICS_THERMAL_MAPPING_MIN: {
                temperature = 1000.0;
                for(unsigned y = floorplan->grid.bottom_index; y <= floorplan->grid.top_index; y++) {
                    for(unsigned x = floorplan->grid.left_index; x <= floorplan->grid.right_index; x++) {
                        if(temperature > Tw_grid[x+y*config->Nx+floorplan->get_layer()*config->Nx*config->Ny])
                            temperature = Tw_grid[x+y*config->Nx+floorplan->get_layer()*config->Nx*config->Ny];
                    }
                }
                break;
            };
            default: {
                cout << "Error (microfluidics): unknown grid to floorplan temperature mapping type" << endl;
                exit(EXIT_FAILURE);
            };
        }
        floorplan->set_temperature(temperature);
    }
}
    
void microfluidics_t::add_floorplan(string Name, double XLeft, double YBottom, double Width, double Height, unsigned Layer)
{
    // Create a new floorplan
    microfluidics_floorplan_t *floorplan = new microfluidics_floorplan_t(Name,XLeft,YBottom,Width,Height,Layer);
    
    // Resize the chip dimension
    if((floorplan->get_x_right()-config->W)>config->floorplan_precision)
        config->W = floorplan->get_x_right();
    if((floorplan->get_y_top()-config->H)>config->floorplan_precision)
        config->H = floorplan->get_y_top();
     
    // Count the number of layers in the package.   
    if((Layer+1) > config->Nz) {
        config->Nz = Layer+1;
    }

    // Store the floorplan information
    floorplans.push_back(floorplan);
    
    // Store the floorplan vector index in the map with the name key.
    assert(floorplans_index.count(floorplan->get_name()) == 0);
    floorplans_index[floorplan->get_name()] = floorplans.size()-1;
}

const unsigned microfluidics_t::get_floorplan_index(string Name)
{
    assert(floorplans_index.count(Name));
    return (unsigned)floorplans_index[Name];
}

microfluidics_floorplan_t* microfluidics_t::get_floorplan(string Name)
{
    return floorplans[get_floorplan_index(Name)];
}

microfluidics_floorplan_t* microfluidics_t::get_floorplan(unsigned Index)
{
    return floorplans[Index];
}

void microfluidics_t::set_floorplan_power(string Name, double Power)
{
    set_floorplan_power(get_floorplan_index(Name),Power);
}

void microfluidics_t::set_floorplan_power(unsigned Index, double Power)
{
    floorplans[Index]->set_power(Power);
#ifdef MICROFLUIDICS_DEBUG
    cout << floorplans[Index]->get_name() << ".power = " << Power << endl;
#endif
}

void microfluidics_t::check_floorplan(microfluidics_floorplan_t *Floorplan)
{
    vector<bool> check_sides;
    check_sides.assign(4,true);
    if(Floorplan->get_x_left() < config->floorplan_precision) {
#ifdef MICROFLUIDICS_DEBUG
        cout << Floorplan->get_name() << " is left most floorplan" << endl;
#endif
        check_sides[0] = false; // Left-most floorplan
    }
    if(fabs(Floorplan->get_x_right()-config->W) < config->floorplan_precision) {
#ifdef MICROFLUIDICS_DEBUG
        cout << Floorplan->get_name() << " is right most floorplan" << endl;
#endif
        check_sides[1] = false; // Right-most floorplan
    }
    if(Floorplan->get_y_bottom() < config->floorplan_precision) {
#ifdef MICROFLUIDICS_DEBUG
        cout << Floorplan->get_name() << " is bottom most floorplan" << endl;
#endif
        check_sides[2] = false; // Bottom-most floorplan
    }
    if(fabs(Floorplan->get_y_top()-config->H) < config->floorplan_precision) {
#ifdef MICROFLUIDICS_DEBUG
        cout << Floorplan->get_name() << " is top most floorplan" << endl;
#endif
        check_sides[3] = false; // Top-most floorplan
    }
    
    for(unsigned i = 0; i < floorplans.size(); i++) {
        if((Floorplan->get_layer() == floorplans[i]->get_layer())&&
           (Floorplan->get_name() != floorplans[i]->get_name())) {
            for(unsigned j = 0; j < 4; j++) { // 4 corners or sides
                // Check if the floorplan overlaps or is disjoint with other floorplans
                double corner_x, corner_y;
                string corner_x_name, corner_y_name;
                switch(j) {
                    case 0: { 
                        corner_x = Floorplan->get_x_left(); corner_y = Floorplan->get_y_bottom();
                        corner_x_name = "left"; corner_y_name = "bottom";
                        
                        if(check_sides[j]) {
                            if(fabs(Floorplan->get_x_left()-floorplans[i]->get_x_right()) < config->floorplan_precision)
                                check_sides[j] = false;
                        }
                        break; 
                    }
                    case 1: { 
                        corner_x = Floorplan->get_x_right(); corner_y = Floorplan->get_y_bottom();
                        corner_x_name = "right"; corner_y_name = "bottom";
                        
                        if(check_sides[j]) {
                            if(fabs(Floorplan->get_x_right()-floorplans[i]->get_x_left()) < config->floorplan_precision)
                                check_sides[j] = false;
                        }
                        break; 
                    }
                    case 2: { 
                        corner_x = Floorplan->get_x_left(); corner_y = Floorplan->get_y_top(); 
                        corner_x_name = "left"; corner_y_name = "top";
                        
                        if(check_sides[j]) {
                            if(fabs(Floorplan->get_y_bottom()-floorplans[i]->get_y_top()) < config->floorplan_precision)
                                check_sides[j] = false;
                        }
                        break; 
                    }
                    case 3: {
                        corner_x = Floorplan->get_x_right(); corner_y = Floorplan->get_y_top();
                        corner_x_name = "right"; corner_y_name = "top";
                        
                        if(check_sides[j]) {
                            if(fabs(Floorplan->get_y_top()-floorplans[i]->get_y_bottom()) < config->floorplan_precision)
                                check_sides[j] = false;
                        }
                        break;
                    }
                    default: break;
                }
                
                if(((corner_x-floorplans[i]->get_x_left()) > config->floorplan_precision)&&
                   ((floorplans[i]->get_x_right()-corner_x) > config->floorplan_precision)&&
                   ((corner_y-floorplans[i]->get_y_bottom()) > config->floorplan_precision)&&
                   ((floorplans[i]->get_y_top()-corner_y) > config->floorplan_precision)) {
                    cout << "Error (microfluidics): Floorplan " << Floorplan->get_name()
                        << "(L=" << Floorplan->get_x_left() << ",R=" << Floorplan->get_x_right()
                        << ",B=" << Floorplan->get_y_bottom() << ",T=" << Floorplan->get_y_top()
                        << ") overlaps with floorplan " << floorplans[i]->get_name()
                        << "(L=" << floorplans[i]->get_x_left() << ",R=" << floorplans[i]->get_x_right()
                        << ",B=" << floorplans[i]->get_y_bottom() << ",T=" << floorplans[i]->get_y_top()
                        << ") at the " << corner_x_name << "_" << corner_y_name << " corner" << endl;
                        exit(EXIT_FAILURE);
                }
            }
        }
    }
    
    for(unsigned i = 0; i < 4; i++) {
        if(check_sides[i]) {
            cout << "Error (microfluidics): Floorplan " << Floorplan->get_name() 
            << "(L=" << Floorplan->get_x_left() << ",R=" << Floorplan->get_x_right()
            << ",B=" << Floorplan->get_y_bottom() << ",T=" << Floorplan->get_y_top()
            << ") is disjoint at the ";
            switch(i) {
                case 0: { cout << "left"; break; }
                case 1: { cout << "right"; break; }
                case 2: { cout << "bottom"; break; }
                case 3: { cout << "top"; break; }
                default: break;
            }
            cout << " side" << endl;
            exit(EXIT_FAILURE);
        }
    }
    check_sides.clear();
}

void microfluidics_t::calculate_steady_state_temperature()
{
    double V_init = 0.0001;
    double error = 1.0;
    double V_max = 0.0;
    
    double ReD = 0.0, FF = 0.0, deltaP = 0.0, PPP = 0.0;
    while(error > 1e-6) {
        V_max = V_init;
        ReD = config->rho_f*V_max*config->Dp/config->mu_f;

        //FF = 3.1335*pow((config->ST/config->Dp-1.0),(-0.5553))*pow((config->SL/config->Dp-1),(-0.4965))*pow((config->HC/config->Dp),(-0.4485))*pow(ReD,(-0.6292))*(ReD<100.0||ReD==100.0)+1.246*pow((config->ST/config->Dp-1.0),(-0.4615))*pow((config->SL/config->Dp-1),(-0.4478))*pow((config->HC/config->Dp),(-0.3362))*pow(ReD,(-0.4393))*(ReD>100.0);
        if(ReD > 100.0) {
            FF = 1.246*pow((config->ST/config->Dp-1.0),-0.4615)*pow((config->SL/config->Dp-1.0),-0.4478)*
                 pow((config->HC/config->Dp),-0.3362)*pow(ReD,-0.4393);
        }
        else { // ReD <= 100.0
            FF = 3.1335*pow((config->ST/config->Dp-1.0),-0.5553)*pow((config->SL/config->Dp-1.0),-0.4965)*
                 pow((config->HC/config->Dp),-0.4485)*pow(ReD,-0.6292);
        }
        
        deltaP = FF*2.0*config->rho_f*V_max*V_max*config->H/config->Dp;
        PPP = deltaP*V_max*(config->ST-config->Dp)*config->NW*config->HC;
        error = fabs(PPP*2.0-config->PPower);
        V_init = V_init+1e-5;
    }
    
    //double Colbj=0.5885*pow((config->ST/Dp-1),(-0.1289))*pow((config->SL/Dp-1),(-0.1432))*pow((HC/Dp),(0.0072))*pow(ReD,(-0.5697))*(ReD<100||ReD==100)+0.4481*pow((config->ST/Dp-1),(0.0804))*pow((config->SL/Dp-1),(-0.1707))*pow((HC/Dp),(-0.1285))*pow(ReD,(-0.4864))*(ReD>100);
    double Colbj = 0.0;
    if(ReD > 100.0) {
        Colbj = 0.4481*pow((config->ST/config->Dp-1),0.0804)*pow((config->SL/config->Dp-1.0),-0.1707)*
                pow((config->HC/config->Dp),-0.1285)*pow(ReD,-0.4864);
    }
    else { // ReD <= 100.0
        Colbj = 0.5885*pow((config->ST/config->Dp-1.0),-0.1289)*pow((config->SL/config->Dp-1.0),-0.1432)*
                pow((config->HC/config->Dp),0.0072)*pow(ReD,-0.5697);
    }
    
    double Pr_f = config->mu_f/config->rho_f/(config->k_f/config->rho_f/config->cp_f);
    double Nu = Colbj*ReD*pow(Pr_f,0.3333);
    double HTC= Nu*config->k_f/config->Dp;
    double mass = V_max*config->rho_f*(config->ST-config->Dp)*config->HC;
    
    double mm = sqrt(HTC*M_PI*config->Dp/config->k_Si/(M_PI*config->Dp*config->Dp/4.0));
    double mL = config->HC*sqrt(HTC*M_PI*config->Dp/config->k_Si/(M_PI*config->Dp*config->Dp/4.0));
    double mLc = (config->HC+config->Dp/4.0)*sqrt(HTC*M_PI*config->Dp/config->k_Si/(M_PI*config->Dp*config->Dp/4.0));
    double etaf = tanh(mL)/mL;
    double etafc = tanh(mLc)/mLc;

    double Af = M_PI*config->Dp*config->HC;
    double Ac = M_PI*config->Dp*config->Dp/4.0;
    double Ab = config->ST*config->SL-Ac;
    double At = config->ST*config->SL-M_PI*config->Dp*config->Dp/4.0+M_PI*config->Dp*config->HC;
    double eta = 1.0-Af/At*(1.0-etaf); 
    double etac = 1.0-Af/At*(1.0-etafc);

    double AAA = sinh(mL)/mm/config->ThSi+cosh(mL)+config->k_Si*config->ThO/config->k_O*(cosh(mL)/config->ThSi+mm*sinh(mL));
    double BBB = sinh(mL)/mm/config->ThSi+config->k_Si*config->ThO*cosh(mL)/config->k_O/config->ThSi;
    double CCC = config->k_Si*config->ThO*mm*sinh(mL)/config->k_O+cosh(mL)-1.0;

    double aaafin = -config->k_Si*Ac/AAA/config->ThSi; //T2
    double bbbfin = -config->k_Si*Ac*(BBB/AAA-1.0)/config->ThSi;//T1
    double cccfin = -config->k_Si*Ac*CCC/AAA/config->ThSi; //Tf

    double aaacond = -config->k_Si*Ac*(cosh(mL)/AAA/config->ThSi+mm*sinh(mL)/AAA); //T2
    double bbbcond = -config->k_Si*Ac*(BBB*cosh(mL)/AAA/config->ThSi-cosh(mL)/config->ThSi+mm*sinh(mL)*BBB/AAA); //T1
    double ccccond = -config->k_Si*Ac*(CCC*cosh(mL)/AAA/config->ThSi+CCC*mm*sinh(mL)/AAA-mm*sinh(mL)); //Tf

    double RF2 = 1.0/HTC/etac/(Ab+M_PI*config->Dp*(config->HC+config->Dp/4.0))+config->ThSi/config->k_Si/config->ST/config->SL;
    
    // Solid resistance for layers
    double Rw[config->Nz];
    double Re[config->Nz];
    double Rn[config->Nz];
    double Rs[config->Nz];
    double Rd[config->Nz];
    for(unsigned z = 0; z < config->Nz; z++) {
        if(z == 0) {
            Rw[z] = config->ST/(config->k_Si*config->SL*config->ThSi+config->k_O*config->SL*config->ThB);
            Re[z] = config->ST/(config->k_Si*config->SL*config->ThSi+config->k_B*config->SL*config->ThB);
            Rn[z] = config->SL/(config->k_Si*config->ST*config->ThSi+config->k_B*config->ST*config->ThB);
            Rs[z] = config->SL/(config->k_Si*config->ST*config->ThSi+config->k_B*config->ST*config->ThB);
            Rd[z] = (config->ThB/(config->k_B*config->ST*config->SL)+1.0/config->heff/(config->ST*config->SL));
        }
        else {
            Rw[z] = config->ST/(config->k_Si*config->SL*config->ThSi+config->k_O*config->SL*config->ThO);
            Re[z] = config->ST/(config->k_Si*config->SL*config->ThSi+config->k_O*config->SL*config->ThO);
            Rn[z] = config->SL/(config->k_Si*config->ST*config->ThSi+config->k_O*config->ST*config->ThO);
            Rs[z] = config->SL/(config->k_Si*config->ST*config->ThSi+config->k_O*config->ST*config->ThO);
            Rd[z] = 1.0/bbbcond;
        }
    }

    double Tw_old[config->Nx*config->Ny*config->Nz];
    double Tf_old[config->Nx*config->Ny*config->Nz];
    double aw[config->Nx*config->Ny*config->Nz];
    double ae[config->Nx*config->Ny*config->Nz];
    double an[config->Nx*config->Ny*config->Nz];
    double as[config->Nx*config->Ny*config->Nz];
    double ad[config->Nx*config->Ny*config->Nz];
    double au[config->Nx*config->Ny*config->Nz];
    double auC[config->Nx*config->Ny*config->Nz];
    double adC[config->Nx*config->Ny*config->Nz];
    double adF[config->Nx*config->Ny*config->Nz];
    double auF[config->Nx*config->Ny*config->Nz];
    double aLF[config->Nx*config->Ny*config->Nz];
    double aRF[config->Nx*config->Ny*config->Nz];
    double ap[config->Nx*config->Ny*config->Nz];
    double apf[config->Nx*config->Ny*config->Nz];
    
    for(unsigned z = 0; z < config->Nz; z++) {
        for(unsigned y = 0; y < config->Ny; y++) {
            for(unsigned x = 0; x < config->Nx; x++) {
                Tw_grid[x+y*config->Nx+z*config->Nx*config->Ny] = config->Twini;
                Tw_old[x+y*config->Nx+z*config->Nx*config->Ny] = config->Twini;
                Tf_grid[x+y*config->Nx+z*config->Nx*config->Ny] = config->Tfin;
                Tf_old[x+y*config->Nx+z*config->Nx*config->Ny] = config->Tfin;

                aw[x+y*config->Nx+z*config->Nx*config->Ny] = 1.0/Rw[z];
                ae[x+y*config->Nx+z*config->Nx*config->Ny] = 1.0/Re[z];
                an[x+y*config->Nx+z*config->Nx*config->Ny] = 1.0/Rn[z];
                as[x+y*config->Nx+z*config->Nx*config->Ny] = 1.0/Rs[z];
                ad[x+y*config->Nx+z*config->Nx*config->Ny] = 1.0/Rd[z];

                if(z == 0) {
                    au[x+y*config->Nx+z*config->Nx*config->Ny] = -aaafin;
                    auC[x+y*config->Nx+z*config->Nx*config->Ny] = 1.0/(config->ThSi/config->k_Si/Ab+1.0/HTC/Ab)-cccfin;
                    adF[x+y*config->Nx+z*config->Nx*config->Ny] = bbbfin-bbbcond+1.0/(config->ThSi/config->k_Si/Ab+1.0/HTC/Ab);
                    auF[x+y*config->Nx+z*config->Nx*config->Ny] = aaafin-aaacond+1.0/(config->ThO/config->k_O/Ab+1.0/HTC/Ab);
                    aLF[x+y*config->Nx+z*config->Nx*config->Ny] = 0.0;
                    aRF[x+y*config->Nx+z*config->Nx*config->Ny] = 0.0;
                }
                else {
                    auC[x+y*config->Nx+z*config->Nx*config->Ny] = 1.0/RF2;
                    adC[x+y*config->Nx+z*config->Nx*config->Ny] = 1.0/(config->ThO/config->k_O/Ab+1.0/HTC/Ab)+ccccond;
                }

                if(x == 1) {
                    aw[x+y*config->Nx+z*config->Nx*config->Ny] = 0.0;
                    aLF[x+y*config->Nx+z*config->Nx*config->Ny] = 0.0;
                }
                else if(x == (config->Nx-2)) {
                    ae[x+y*config->Nx+z*config->Nx*config->Ny] = 0.0;
                    aRF[x+y*config->Nx+z*config->Nx*config->Ny] = 0.0;
                }

                if(y == 1) {
                    as[x+y*config->Nx+z*config->Nx*config->Ny] = 0.0;
                }
                else if(y == (config->Ny-2)) {
                    an[x+y*config->Nx+z*config->Nx*config->Ny] = 0.0;
                }

                if(z == 0) {
                    ap[x+y*config->Nx+z*config->Nx*config->Ny] = aw[x+y*config->Nx+z*config->Nx*config->Ny]+ae[x+y*config->Nx+z*config->Nx*config->Ny]+an[x+y*config->Nx+z*config->Nx*config->Ny]+as[x+y*config->Nx+z*config->Nx*config->Ny]+ad[x+y*config->Nx+z*config->Nx*config->Ny]+1.0/(config->ThSi/config->k_Si/Ab+1/HTC/Ab)+bbbfin;
                    apf[x+y*config->Nx+z*config->Nx*config->Ny] = -(cccfin-ccccond-1.0/(config->ThSi/config->k_Si/Ab+1/HTC/Ab)-1.0/(config->ThO/config->k_O/Ab+1/HTC/Ab))+mass*config->cp_f;
                }
                else {
                    ap[x+y*config->Nx+z*config->Nx*config->Ny] = aw[x+y*config->Nx+z*config->Nx*config->Ny]+ae[x+y*config->Nx+z*config->Nx*config->Ny]+an[x+y*config->Nx+z*config->Nx*config->Ny]+as[x+y*config->Nx+z*config->Nx*config->Ny]+auC[x+y*config->Nx+z*config->Nx*config->Ny]-aaacond+1.0/(config->ThO/config->k_O/Ab+1/HTC/Ab);
                    apf[x+y*config->Nx+z*config->Nx*config->Ny] = auC[x+y*config->Nx+z*config->Nx*config->Ny]+mass*config->cp_f;
                }
            }
        }
    } 

    error = 1.0;
    while(error > 1e-8) {
        memcpy(Tw_old,Tw_grid,sizeof(double)*config->Nx*config->Ny*config->Nz);
        memcpy(Tf_old,Tf_grid,sizeof(double)*config->Nx*config->Ny*config->Nz);

        for(unsigned z = 0; z < config->Nz; z++) {
            for(unsigned y = 1; y < (config->Ny-1); y++) {
                for(unsigned x = 1; x < (config->Nx-1); x++) {
                    if(z == 0) {
                        Tf_grid[x+y*config->Nx+z*config->Nx*config->Ny] = (Tw_grid[x+y*config->Nx+z*config->Nx*config->Ny]*adF[x+y*config->Nx+z*config->Nx*config->Ny]+Tf_grid[(x-1)+y*config->Nx+z*config->Nx*config->Ny]*aLF[x+y*config->Nx+z*config->Nx*config->Ny]+Tf_grid[(x+1)+y*config->Nx+z*config->Nx*config->Ny]*aRF[x+y*config->Nx+z*config->Nx*config->Ny]+Tw_grid[x+y*config->Nx+(z+1)*config->Nx*config->Ny]*auF[x+y*config->Nx+z*config->Nx*config->Ny]+mass*config->cp_f*Tf_grid[x+(y-1)*config->Nx+z*config->Nx*config->Ny])/apf[x+y*config->Nx+z*config->Nx*config->Ny];
                    }
                    else {
                        Tf_grid[x+y*config->Nx+z*config->Nx*config->Ny] = (Tw_grid[x+y*config->Nx+z*config->Nx*config->Ny]*auC[x+y*config->Nx+z*config->Nx*config->Ny]+mass*config->cp_f*Tf_grid[x+(y-1)*config->Nx+z*config->Nx*config->Ny])/apf[x+y*config->Nx+z*config->Nx*config->Ny];
                    }
                }
            }
        }
        
        double P[config->Nx];
        double Q[config->Nx];
        double PP[config->Ny];
        double QQ[config->Ny];
        double a, b, c, d;
        double error_Tw = 0.0;
        double error_Tf = 0.0;
        double Twe[config->Nx*config->Ny*config->Nz];
        double Tfe[config->Nx*config->Ny*config->Nz];
        for(unsigned z = 0; z < config->Nz; z++) {
            for(unsigned y = 1; y < (config->Ny-1); y++) {
                P[0] = 0.0;
                Q[0] = Tw_grid[0+y*config->Nx+z*config->Nx*config->Ny];
                for(unsigned x = 1; x < (config->Nx-1); x++) {
                    a = ap[x+y*config->Nx+z*config->Nx*config->Ny];
                    b = ae[x+y*config->Nx+z*config->Nx*config->Ny];
                    c = aw[x+y*config->Nx+z*config->Nx*config->Ny];
                    if(z == 0) {
                        d = power_grid[x+y*config->Nx+z*config->Nx*config->Ny]+an[x+y*config->Nx+z*config->Nx*config->Ny]*Tw_grid[x+(y+1)*config->Nx+z*config->Nx*config->Ny]+as[x+y*config->Nx+z*config->Nx*config->Ny]*Tw_grid[x+(y-1)*config->Nx+z*config->Nx*config->Ny]+au[x+y*config->Nx+z*config->Nx*config->Ny]*Tw_grid[x+y*config->Nx+(z+1)*config->Nx*config->Ny]+auC[x+y*config->Nx+z*config->Nx*config->Ny]*Tf_grid[x+y*config->Nx+z*config->Nx*config->Ny]+ad[x+y*config->Nx+z*config->Nx*config->Ny]*config->Tamb;
                    }
                    else {
                        d = power_grid[x+y*config->Nx+z*config->Nx*config->Ny]+an[x+y*config->Nx+z*config->Nx*config->Ny]*Tw_grid[x+(y+1)*config->Nx+z*config->Nx*config->Ny]+as[x+y*config->Nx+z*config->Nx*config->Ny]*Tw_grid[x+(y-1)*config->Nx+z*config->Nx*config->Ny]+auC[x+y*config->Nx+z*config->Nx*config->Ny]*Tf_grid[x+y*config->Nx+z*config->Nx*config->Ny]+adC[x+y*config->Nx+z*config->Nx*config->Ny]*Tf_grid[x+y*config->Nx+(z-1)*config->Nx*config->Ny]+ad[x+y*config->Nx+z*config->Nx*config->Ny]*Tw_grid[x+y*config->Nx+(z-1)*config->Nx*config->Ny];
                    }
                    P[x] = b/(a-c*P[x-1]);
                    Q[x] = (c*Q[x-1]+d)/(a-c*P[x-1]);
                }
                for(unsigned x = (config->Nx-2); x > 0; x--) {
                    Tw_grid[x+y*config->Nx+z*config->Nx*config->Ny] = P[x]*Tw_grid[(x+1)+y*config->Nx+z*config->Nx*config->Ny]+Q[x];
                }
            }
            
            for(unsigned x = 1; x < (config->Nx-1); x++) {
                PP[0] = 0.0;
                QQ[0] = Tw_grid[x+0*config->Nx+z*config->Nx*config->Ny];
                for(unsigned y = 1; y < (config->Ny-1); y++) {
                    a = ap[x+y*config->Nx+z*config->Nx*config->Ny];
                    b = an[x+y*config->Nx+z*config->Nx*config->Ny];
                    c = as[x+y*config->Nx+z*config->Nx*config->Ny];
                    if(z == 0) {
                        d = power_grid[x+y*config->Nx+z*config->Nx*config->Ny]+ae[x+y*config->Nx+z*config->Nx*config->Ny]*Tw_grid[(x+1)+y*config->Nx+z*config->Nx*config->Ny]+aw[x+y*config->Nx+z*config->Nx*config->Ny]*Tw_grid[(x-1)+y*config->Nx+z*config->Nx*config->Ny]+au[x+y*config->Nx+z*config->Nx*config->Ny]*Tw_grid[x+y*config->Nx+(z+1)*config->Nx*config->Ny]+auC[x+y*config->Nx+z*config->Nx*config->Ny]*Tf_grid[x+y*config->Nx+z*config->Nx*config->Ny]+ad[x+y*config->Nx+z*config->Nx*config->Ny]*config->Tamb;
                    }
                    else {
                        d = power_grid[x+y*config->Nx+z*config->Nx*config->Ny]+ae[x+y*config->Nx+z*config->Nx*config->Ny]*Tw_grid[(x+1)+y*config->Nx+z*config->Nx*config->Ny]+aw[x+y*config->Nx+z*config->Nx*config->Ny]*Tw_grid[(x-1)+y*config->Nx+z*config->Nx*config->Ny]+auC[x+y*config->Nx+z*config->Nx*config->Ny]*Tf_grid[x+y*config->Nx+z*config->Nx*config->Ny]+adC[x+y*config->Nx+z*config->Nx*config->Ny]*Tf_grid[x+y*config->Nx+(z-1)*config->Nx*config->Ny]+ad[x+y*config->Nx+z*config->Nx*config->Ny]*Tw_grid[x+y*config->Nx+(z-1)*config->Nx*config->Ny];
                    }
                    PP[y] = b/(a-c*PP[y-1]);
                    QQ[y] = (c*QQ[y-1]+d)/(a-c*PP[y-1]);
                }
                for(unsigned y = (config->Ny-2); y > 0; y--) {
                    Tw_grid[x+y*config->Nx+z*config->Nx*config->Ny] = PP[y]*Tw_grid[x+(y+1)*config->Nx+z*config->Nx*config->Ny]+QQ[y];
                }
            }
        }
        
        for(unsigned z = 0; z < config->Nz; z++) {
            for(unsigned y = 0; y < config->Ny; y++) {
                for(unsigned x = 0; x < config->Nx; x++) {
                    Twe[x+y*config->Nx+z*config->Nx*config->Ny] = Tw_grid[x+y*config->Nx+z*config->Nx*config->Ny]-Tw_old[x+y*config->Nx+z*config->Nx*config->Ny];
                    error_Tw += (fabs(Twe[x+y*config->Nx+z*config->Nx*config->Ny]/Tw_grid[x+y*config->Nx+z*config->Nx*config->Ny]));
                    Tfe[x+y*config->Nx+z*config->Nx*config->Ny] = Tf_grid[x+y*config->Nx+z*config->Nx*config->Ny]-Tf_old[x+y*config->Nx+z*config->Nx*config->Ny];
                    error_Tf += (fabs(Tfe[x+y*config->Nx+z*config->Nx*config->Ny]/Tf_grid[x+y*config->Nx+z*config->Nx*config->Ny]));
                }
            }
        }
        error = error_Tw+error_Tf;
    }
    
    for(unsigned z = 0; z < config->Nz; z++) {
        for(unsigned y = 0; y < config->Ny; y++) {
            Tw_grid[0+y*config->Nx+z*config->Nx*config->Ny] = Tw_grid[1+y*config->Nx+z*config->Nx*config->Ny];
            Tw_grid[(config->Nx-1)+y*config->Nx+z*config->Nx*config->Ny] = Tw_grid[(config->Nx-2)+y*config->Nx+z*config->Nx*config->Ny];
            Tf_grid[0+y*config->Nx+z*config->Nx*config->Ny] = Tf_grid[1+y*config->Nx+z*config->Nx*config->Ny];
            Tf_grid[(config->Nx-1)+y*config->Nx+z*config->Nx*config->Ny] = Tf_grid[(config->Nx-2)+y*config->Nx+z*config->Nx*config->Ny];
        }
        
        for(unsigned x = 0; x < config->Nx; x++) {
            Tw_grid[x+0*config->Nx+z*config->Nx*config->Ny] = Tw_grid[x+1*config->Nx+z*config->Nx*config->Ny];
            Tw_grid[x+(config->Ny-1)*config->Nx+z*config->Nx*config->Ny] = Tw_grid[x+(config->Ny-2)*config->Nx+z*config->Nx*config->Ny];
            Tf_grid[x+(config->Ny-1)*config->Nx+z*config->Nx*config->Ny] = Tf_grid[x+(config->Ny-2)*config->Nx+z*config->Nx*config->Ny];
        }
    }
    
#ifdef MICROFLUIDICS_DEBUG
    cout << "Thermal grid:" << endl;
    for(unsigned z = 0; z < config->Nz; z++) {
        for(unsigned y = 0; y < config->Ny; y++) {
            for(unsigned x = 0; x < config->Nx; x++) {
                cout << Tw_grid[x+y*config->Nx+z*config->Nx*config->Ny] << " ";
            }
            cout << endl;
        }
        cout << endl;
    }
#endif
}

void microfluidics_t::calculate_transient_temperature(double Period)
{
    // Nothing to do
    cout << "Error (microfluidics): this version doesn't support transient simulation." << endl;
    exit(EXIT_FAILURE);
}
