#include <math.h>
#include "tsv.h"

tsv_t::tsv_t() :
    dielectric_constant(8.85e-12),
    relative_dielectric_constant(3.7),
    tsv_height(50e-6),
    tsv_radius(5e-6),
    sidewall_thickness(0.15e-6),
    voltage(1.0)
{}

tsv_t::~tsv_t() {}

double tsv_t::get_capacitance(void) {
  return 2*3.141592*dielectric_constant*relative_dielectric_constant*tsv_height/log((tsv_radius+sidewall_thickness)/tsv_radius);
}

double tsv_t::get_area(void) {
  return 3.141592*pow(tsv_radius,2.0);
}

