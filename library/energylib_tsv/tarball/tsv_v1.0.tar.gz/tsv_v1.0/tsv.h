#ifndef __TSV_MODEL_H__
#define __TSV_MODEL_H__

class tsv_t {
public:
    tsv_t();
    ~tsv_t();

    double get_capacitance(void);
    double get_area(void);
  
    double dielectric_constant;
    double relative_dielectric_constant;
    double tsv_height;
    double tsv_radius;
    double sidewall_thickness;
    double voltage;  
    double clock_frequency;
};

#endif

